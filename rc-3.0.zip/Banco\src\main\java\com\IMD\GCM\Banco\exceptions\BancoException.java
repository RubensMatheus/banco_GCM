package com.IMD.GCM.Banco.exceptions;

public class BancoException extends RuntimeException {
    public BancoException(String message) {
        super(message);
    }
}
